function hidebutton(element) {
    element.remove();
}

var heart = 1;

function heartcount() {
    var num = document.querySelector(".heartcount");
    num.innerText = parseFloat(num.innerText) + 1;
}

function heartcounts() {
    var num = document.querySelector(".heartcounts");
    num.innerText = parseFloat(num.innerText) + 1;
}

function heartcounting() {
    var num = document.querySelector(".heartcounting");
    num.innerText = parseFloat(num.innerText) + 1;
}

function displayName(elementName) {
    console.log(elementName);
}