﻿// See https://aka.ms/new-console-template for more information

Melee bowser = new Melee("Bowser");
Ranged link = new Ranged("Link", 100);
Magic kamek = new Magic("Kamek");

// bowser.PrintInfo();
// link.PrintInfo();
// kamek.PrintInfo();