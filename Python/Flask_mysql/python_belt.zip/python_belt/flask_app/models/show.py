from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models import user

class shows:

    @classmethod
    def get_users_with_shows(cls,data):
        query ="SELECT * FROM users LEFT JOIN shows ON shows.users_id = users.id WHERE users.id = %(id)s;"
        results = connectToMySQL('shows').query_db(query,data)
        shows = cls(results[0])
        for row_from_db in results:
            shows_data = {
                "id" : row_from_db["shows.id"],
                "name" : row_from_db["shows.name"],
                "network" : row_from_db["network"],
                "date_made" : row_from_db["date_made"],
                "description" : row_from_db["description"],
                "created_at" : row_from_db["shows.created_at"],
                "updated_at" : row_from_db["shows.updated_at"]
            }
            shows.user=(shows.user(shows_data))
        return shows

class Show:
    db_name = 'shows'
    def __init__(self,db_data):
        self.id = db_data['id']
        self.name = db_data['name']
        self.network = db_data['network']
        self.date_made = db_data['date_made']
        self.description = db_data['description']
        self.user_id = db_data['user_id']
        self.created_at = db_data['created_at']
        self.updated_at = db_data['updated_at']

    @classmethod
    def save(cls,data):
        query = "INSERT INTO shows (name, network, date_made, description, user_id) VALUES (%(name)s,%(network)s,%(date_made)s,%(description)s,%(user_id)s);"
        return connectToMySQL(cls.db_name).query_db(query, data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM shows;"
        results =  connectToMySQL(cls.db_name).query_db(query)
        all_shows = []
        for row in results:
            print(row['date_made'])
            all_shows.append( cls(row) )
        return all_shows
    
    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM shows WHERE id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        return cls( results[0] )

    @classmethod
    def update(cls, data):
        query = "UPDATE shows SET name=%(name)s, network=%(network)s, date_made=%(date_made)s, description=%(description)s, updated_at=NOW() WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query,data)
    
    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM shows WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query,data)

    @staticmethod
    def validate_show(show):
        is_valid = True
        if len(show['name']) < 3:
            is_valid = False
            flash("Name must be at least 3 characters","show")
        if len(show['network']) < 3:
            is_valid = False
            flash("Network must be at least 3 characters","show")
        if len(show['description']) < 3:
            is_valid = False
            flash("Description must be at least 3 characters","show")
        if show['date_made'] == "":
            is_valid = False
            flash("Please enter a date","show")
        return is_valid